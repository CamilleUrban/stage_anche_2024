Programmes fait dans le cadre du stage de DUT de Lucas Descuns (avril - mai 2017)
Programme principal : programmedyn.m
Ce programme permet d'estimer les paramètres : 
- fréquence fondamentale
- CGS
- Pression seuil
à partir d'une mesure faite en pression d'alimentation décroissante.
